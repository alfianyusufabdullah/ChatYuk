# ChatYuk

Simple Android App Chat Using Firebase :books: :books:

## TODO

* use your own **google-service.json**
* jangan lupa baca bismillah

## Screenshoot

<img src="https://github.com/alfianyusufabdullah/ChatYuk/raw/master/app/screenshoot/ss1.png" width="250"> <img src="https://github.com/alfianyusufabdullah/ChatYuk/raw/master/app/screenshoot/ss2.png" width="250"> <img src="https://github.com/alfianyusufabdullah/ChatYuk/raw/master/app/screenshoot/ss3.png" width="250"> <img src="https://github.com/alfianyusufabdullah/ChatYuk/raw/master/app/screenshoot/ss4.png" width="250"> <img src="https://github.com/alfianyusufabdullah/ChatYuk/raw/master/app/screenshoot/ss5.png" width="250">
